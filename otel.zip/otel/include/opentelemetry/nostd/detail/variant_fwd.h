#pragma once

#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace nostd
{
template <typename... Ts>
class variant;
}  // namespace nostd
OPENTELEMETRY_END_NAMESPACE
